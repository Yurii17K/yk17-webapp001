
CREATE PROCEDURE Decision (
@hero_name VARCHAR (50),
@monster_power FLOAT
) AS (
SELECT @hero_name AS Hero, Armors.state AS condition, Armors.level AS amplifier, @monster_power AS Power_withstanded FROM Heroes AS h
INNER JOIN Armors ON h.armor = Armors.armor
WHERE @hero_name = h.hero AND (@monster_power * ((100.0 - Armors.state)/100) / ((100.0 + Armors.level)/100)) < 100
)
go



CREATE VIEW Master_weapon_dmg AS (
SELECT * FROM Silver_weapons
WHERE weapon LIKE '%Mastercrafted%'
)
go



CREATE VIEW Broken_armor AS (
SELECT armor, state
FROM Armors
WHERE state < 50
)
go


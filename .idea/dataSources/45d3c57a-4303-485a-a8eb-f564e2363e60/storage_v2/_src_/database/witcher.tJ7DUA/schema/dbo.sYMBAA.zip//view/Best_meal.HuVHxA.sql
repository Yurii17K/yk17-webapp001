
-----------------------------------
CREATE VIEW Best_meal AS (
SELECT TOP 100 percent f.meal, (f.effect * f.duration) AS Taste 
FROM Meals AS f
)
go


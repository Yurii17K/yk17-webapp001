
CREATE VIEW Hero_dmg AS (
SELECT h.hero, Silver_weapons.damage FROM Heroes AS h
INNER JOIN Silver_weapons ON h.silver_weapon = Silver_weapons.weapon
)
go


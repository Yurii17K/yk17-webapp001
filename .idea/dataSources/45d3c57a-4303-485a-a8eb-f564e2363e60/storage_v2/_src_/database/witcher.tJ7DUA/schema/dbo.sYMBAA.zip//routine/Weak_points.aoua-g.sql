
-----------------------------------
CREATE PROCEDURE Weak_points (
@monster_name VARCHAR (50)
) AS (
SELECT @monster_name AS m_name, aux_ingr AS weak_point
FROM Oils
WHERE @monster_name = target
)
go

